/*
  ==========================================================
  LOCKER / DESTINATION URL
  ==========================================================
  Replace the value below with YOUR VERIFIED destination.
  Example:
  const LOCKER_URL = "https://example.com/your-offer";
  ==========================================================
*/
const LOCKER_URL = "https://YOUR-LOCKER-LINK-HERE.com";

const modal = document.getElementById("modal");
const percent = document.getElementById("percent");
const bar = document.getElementById("bar");

function openModal() {
  modal.classList.add("show");
  modal.setAttribute("aria-hidden", "false");
  startProgress();
}

function closeModal() {
  modal.classList.remove("show");
  modal.setAttribute("aria-hidden", "true");
}

function startProgress() {
  let value = 0;
  bar.style.width = "0%";
  percent.textContent = "0%";

  const timer = setInterval(() => {
    value += Math.floor(Math.random() * 9) + 7;
    if (value >= 100) {
      value = 100;
      clearInterval(timer);
    }
    bar.style.width = value + "%";
    percent.textContent = value + "%";
  }, 120);
}

document.querySelectorAll("[data-open]").forEach((button) => {
  button.addEventListener("click", openModal);
});

document.querySelector("[data-close]").addEventListener("click", closeModal);

modal.addEventListener("click", (event) => {
  if (event.target === modal) closeModal();
});

document.getElementById("continueBtn").addEventListener("click", () => {
  if (!LOCKER_URL || LOCKER_URL.includes("YOUR-LOCKER")) {
    alert("Add your verified destination URL in script.js first.");
    return;
  }

  window.location.href = LOCKER_URL;
});
